package com.example.rest_peliculas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestPeliculasApplicationTests {

	@Test
	void contextLoads() {
	}

}
