package com.example.res_alumnos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResAlumnosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResAlumnosApplication.class, args);
	}

}
