package com.example.rest_peliculas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestPeliculasApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestPeliculasApplication.class, args);
	}

}
